module Logister
  VERSION = '0.1.2'
end
